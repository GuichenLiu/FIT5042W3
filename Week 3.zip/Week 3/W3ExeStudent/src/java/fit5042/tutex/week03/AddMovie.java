/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fit5042.tutex.week03;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import static com.sun.faces.facelets.util.Path.context;
import java.util.ArrayList;
import javax.el.ELContext;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author Leo Liu
 */
@RequestScoped
@Named("addMovie")
public class AddMovie {

    private boolean showForm = true;
    private Movie movie;
    private final ArrayList<Movie> movies;

    public AddMovie() {
        ELContext context = FacesContext.getCurrentInstance().getELContext();

        MovieApplication app = (MovieApplication) FacesContext.getCurrentInstance().getApplication().getELResolver().getValue(context, null, "movieApplication");

        movies = app.getMovies();
    }
    
    public void addMovie(Movie movie) {
        movies.add(movie);

        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Movie has been added succesfully"));

        showForm = false;

    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public boolean isShowForm() {
        return showForm;
    }

    public void setShowForm(boolean showForm) {
        this.showForm = showForm;
    }

}
